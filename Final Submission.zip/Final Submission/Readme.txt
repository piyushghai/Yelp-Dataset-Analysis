This is a readme for homework 6 submission of CSE 5243.
The zip file : Project6 contains following Python files of significance : 

PreProcessing1.py
PreProcessing2.py
LDA_model.py
LDA_Sentiment_model.py
BiGram_Model.py
BiAndTriGram_Model.py	
Baseline_Model.py
BagOfWords_Model.py
TFIDF_model.py
TriGram_Model.py

Note : Run the files in the order specified, as they generate intermediate files which are then needed by other model files. 

The Dataset is too huge and cannot be attached along with this. 
To download the dataset head over to :
 
https://www.yelp.com/dataset_challenge